script = [];

note.octave = 0;
note.semitone = {'-1'};
note.duration = T/2;
script = [script note];

note.octave = [-1 -1 -1];
note.semitone = {'C' 'G' 'E'};
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = {'D'};
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = {'C'};
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = {'D'};
note.duration = T;
script = [script note];

note.octave = [-1 -1 -1];
note.semitone = {'C' 'G' 'E'};
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = {'E'};
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = {'E'};
note.duration = 2*T;
script = [script note];

note.octave = [-2 -1 -1];
note.semitone = {'G' 'B' 'D'};
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = {'D'};
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = {'D'};
note.duration = 2*T;
script = [script note];

note.octave = [-1 -1 -1];
note.semitone = {'C' 'G' 'E'};
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = {'G'};
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = {'G'};
note.duration = 2*T;
script = [script note];