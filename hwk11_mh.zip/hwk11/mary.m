script = [];

note.octave = 0;
note.semitone = 'B';
note.duration = T;
script = [script note];

note.octave = 0;
note.semitone = 'A';
note.duration = T;
script = [script note];

note.octave = -1;
note.semitone = 'G';
note.duration = T;
script = [script note];

note.octave = 0;
note.semitone = 'A';
note.duration = T;
script = [script note];

note.octave = 0;
note.semitone = 'B';
note.duration = T;
script = [script note];

note.octave = 0;
note.semitone = 'B';
note.duration = T;
script = [script note];

note.octave = 0;
note.semitone = 'B';
note.duration = 2*T;
script = [script note];

note.octave = 0;
note.semitone = 'A';
note.duration = T;
script = [script note];

note.octave = 0;
note.semitone = 'A';
note.duration = T;
script = [script note];

note.octave = 0;
note.semitone = 'A';
note.duration = 2*T;
script = [script note];

note.octave = 0;
note.semitone = 'B';
note.duration = T;
script = [script note];

note.octave = 0;
note.semitone = 'D';
note.duration = T;
script = [script note];

note.octave = 0;
note.semitone = 'D';
note.duration = 2*T;
script = [script note];
